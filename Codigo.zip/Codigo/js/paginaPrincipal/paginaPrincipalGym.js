//Ahora voy a relizar el codigo de JS para el tema del carrusel de imágenes.

//operacion: calcula el desplazamiento.
//counter: sigue el índice de la sección.
//widthImg: calcula el ancho de cada imagen en porcentaje.
//moveTo: desplazamiento de los botones izquiero y derecho
//El código de es un video pero se ha entendido bastante la verdad. https://youtu.be/mgoNOkFGmto


const btnLeft = document.querySelector(".btn-left"),
      btnRight = document.querySelector(".btn-right"),
      slide = document.querySelector("#slide"),
      slideSection = document.querySelectorAll(".slide-section");


btnLeft.addEventListener("click", e => moveToLeft())
btnRight.addEventListener("click", e => moveToRight())

setInterval(() => {
    moveToRight()
}, 3000);


let operacion = 0,
    counter = 0,
    widthImg = 100 / slideSection.length;

function moveToRight() {                        
    if (counter >= slideSection.length-1) {
        counter = 0;
        operacion = 0;
        slide.style.transform = `translate(-${operacion}%)`;
        slide.style.transition = "none";
        return;
    } 
    counter++;
    operacion = operacion + widthImg;
    slide.style.transform = `translate(-${operacion}%)`;
    slide.style.transition = "all ease .3s";
}  

function moveToLeft() {
    counter--;
    if (counter < 0 ) {
        counter = slideSection.length-1;
        operacion = widthImg * (slideSection.length-1)
        slide.style.transform = `translate(-${operacion}%)`;
        slide.style.transition = "none";
        return;
    } 
    operacion = operacion - widthImg;
    slide.style.transform = `translate(-${operacion}%)`;
    slide.style.transition = "all ease .3s" ;
}   

document.addEventListener("DOMContentLoaded", function() {
    var avisoCookies = document.getElementById("avisoCookies");
    var cookiesForm = document.getElementById("cookiesForm");

    // Comprobar si el usuario ya aceptó las cookies
    if (!cookiesAceptadas()) { mostrarAvisoCookies();}

    // Mostrar el aviso de cookies
    function mostrarAvisoCookies() {
        avisoCookies.style.display = "block";
    }

    // Ocultar el aviso de cookies y almacenar las preferencias del usuario
    function aceptarCookies(event) {
        event.preventDefault();
        avisoCookies.style.display = "none";
        almacenarCookiesAceptadas();
    }

    // Función para verificar si el usuario ya aceptó las cookies
    function cookiesAceptadas() {
        return localStorage.getItem("cookiesAceptadas") === "true";
    }

    // Función para almacenar las preferencias del usuario en el almacenamiento local
    function almacenarCookiesAceptadas() {
        var checkboxes = cookiesForm.querySelectorAll("input[type=checkbox]:checked");
        localStorage.setItem("cookiesAceptadas", "true");
        checkboxes.forEach(function(checkbox) {
            localStorage.setItem(checkbox.name, "true");
        });
    }

    // Agregar evento de envío al formulario de cookies
    cookiesForm.addEventListener("submit", aceptarCookies);

    // Ocultar el aviso de cookies si ya han sido aceptadas
    if (cookiesAceptadas()) {
        avisoCookies.style.display = "none";
    }
});
